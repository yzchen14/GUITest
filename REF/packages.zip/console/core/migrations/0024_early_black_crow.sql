ALTER TABLE `user` DROP COLUMN `old_account_id`;--> statement-breakpoint
ALTER TABLE `user` DROP COLUMN `old_email`;