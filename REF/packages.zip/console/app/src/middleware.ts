import { createMiddleware } from "@solidjs/start/middleware"

export default createMiddleware({
  onBeforeResponse() {},
})
