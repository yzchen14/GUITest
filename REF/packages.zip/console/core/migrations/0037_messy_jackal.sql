ALTER TABLE `billing` ADD `reload_trigger` int;--> statement-breakpoint
ALTER TABLE `billing` ADD `reload_amount` int;