This is a temporary package used primarily for GitHub Copilot compatibility.

Avoid making changes to these files unless you only want to affect the Copilot provider.

Also, this should ONLY be used for the Copilot provider.
