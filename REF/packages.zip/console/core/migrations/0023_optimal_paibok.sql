CREATE INDEX `global_account_id` ON `user` (`account_id`);--> statement-breakpoint
CREATE INDEX `global_email` ON `user` (`email`);