# Mermaid Chat Features

**Notice:** This extension is bundled with Visual Studio Code. It can be disabled but not uninstalled.

Adds basic [Mermaid.js](https://mermaid.js.org) diagram rendering to build-in chat.
