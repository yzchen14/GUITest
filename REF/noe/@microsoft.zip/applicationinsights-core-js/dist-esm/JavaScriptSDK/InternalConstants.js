/*
 * Application Insights JavaScript SDK - Core, 2.8.15
 * Copyright (c) Microsoft and contributors. All rights reserved.
 */


// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// Note: DON'T Export these const from the package as we are still targeting ES3 this will export a mutable variables that someone could change!!!
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
export var STR_EMPTY = "";
export var STR_CHANNELS = "channels";
export var STR_CORE = "core";
export var STR_CREATE_PERF_MGR = "createPerfMgr";
export var STR_DISABLED = "disabled";
export var STR_EXTENSION_CONFIG = "extensionConfig";
export var STR_EXTENSIONS = "extensions";
export var STR_PROCESS_TELEMETRY = "processTelemetry";
export var STR_PRIORITY = "priority";
export var STR_EVENTS_SENT = "eventsSent";
export var STR_EVENTS_DISCARDED = "eventsDiscarded";
export var STR_EVENTS_SEND_REQUEST = "eventsSendRequest";
export var STR_PERF_EVENT = "perfEvent";
export var STR_ERROR_TO_CONSOLE = "errorToConsole";
export var STR_WARN_TO_CONSOLE = "warnToConsole";
export var STR_GET_PERF_MGR = "getPerfMgr";