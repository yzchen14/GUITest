/*
 * 1DS JS SDK POST plugin, 3.2.13
 * Copyright (c) Microsoft and contributors. All rights reserved.
 * (Microsoft Internal Only)
 */
export {};
// export declare var XDomainRequest: {
//     prototype: IXDomainRequest;
//     new (): IXDomainRequest;
// };