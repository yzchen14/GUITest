import { ParentProps } from "solid-js"

export default function Share(props: ParentProps) {
  return props.children
}
